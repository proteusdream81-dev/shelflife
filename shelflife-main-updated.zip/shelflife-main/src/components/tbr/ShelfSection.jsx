import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Lock, Share2, Pencil, Trash2, MoreVertical, MessageCircle } from "lucide-react";
import ShelfGrid from "@/components/tbr/ShelfGrid";
import ShelfProgress from "@/components/tbr/ShelfProgress";
import ConfirmDialog from "@/components/tbr/ConfirmDialog";
import ShareDialog from "@/components/tbr/ShareDialog";
import ShelfForm from "@/components/tbr/ShelfForm";
import CommentsPanel from "@/components/tbr/CommentsPanel";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function ShelfSection({
  shelf, books, allShelves, onChange, onBookSaved, isPrivate, group = "none", showWarnings,
  // Every book on the shelf, even while a search or a format filter is narrowing the grid, so
  // the progress shown is the shelf's own.
  summaryBooks,
}) {
  const [shareOpen, setShareOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  // The discussion on a shared shelf, which the reader who shared it can read and answer here
  // rather than only through the link they sent.
  const [discussionOpen, setDiscussionOpen] = useState(false);
  // Only books filed on this shelf are removed with it; a book that shows here through its
  // status or another shelf of its own stays where it is.
  const ownCount = books.filter((book) => book.shelf_id === shelf.id).length;

  const handleDelete = async () => {
    await base44.entities.Book.deleteMany({ shelf_id: shelf.id });
    await base44.entities.Shelf.delete(shelf.id);
    setConfirmDelete(false);
    onChange();
  };

  return (
    <section className="vp-shelf">
      <div className="vp-shelfhead">
        <div className="vp-titleline">
          <h2>{shelf.name}</h2>
          {isPrivate && <Lock className="w-4 h-4 text-muted-foreground" strokeWidth={1.8} />}
          <span className="vp-badge">{books.length}</span>
        </div>
        <div className="vp-shelfops">
          {shelf.share_enabled === true && (
            <button
              type="button"
              className={`vp-btn vp-small ${discussionOpen ? "vp-active" : ""}`}
              aria-expanded={discussionOpen}
              onClick={() => setDiscussionOpen((open) => !open)}
            >
              <MessageCircle strokeWidth={1.8} /> Discussion
            </button>
          )}
          <button type="button" className="vp-btn vp-small" onClick={() => setShareOpen(true)}>
            <Share2 strokeWidth={1.8} /> Share
          </button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button type="button" className="vp-btn vp-icon vp-small" aria-label="Shelf menu">
                <MoreVertical strokeWidth={1.8} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setEditOpen(true)}><Pencil className="w-4 h-4 mr-2" /> Edit shelf</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setConfirmDelete(true)} className="text-destructive"><Trash2 className="w-4 h-4 mr-2" /> Delete shelf</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <ShelfProgress books={summaryBooks || books} />

      {books.length === 0 ? (
        <p className="vp-empty">No books here yet.</p>
      ) : (
        <ShelfGrid
          books={books}
          shelves={allShelves}
          group={group}
          showWarnings={showWarnings}
          onSaved={onBookSaved || onChange}
          onRemoved={onChange}
        />
      )}

      {shelf.share_enabled === true && discussionOpen && (
        <CommentsPanel shelfId={shelf.id} className="mt-4" />
      )}

      <ConfirmDialog
        open={confirmDelete}
        onOpenChange={setConfirmDelete}
        title={`Delete “${shelf.name}”?`}
        description={`The shelf and the ${ownCount} ${ownCount === 1 ? "book" : "books"} filed on it will be removed.${ownCount !== books.length ? " Books that only show here through their status or another shelf stay where they are." : ""} This can't be undone.`}
        confirmLabel="Delete shelf"
        onConfirm={handleDelete}
      />

      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} shelf={shelf} onSaved={onChange} />
      <ShelfForm open={editOpen} onOpenChange={setEditOpen} shelf={shelf} onSaved={onChange} />
    </section>
  );
}