// Who spoke last in a comment thread. A thread is one comment and the replies hung under it,
// so the newest of those is the voice a new reply would be answering. A reader may reply when
// that voice is someone else's: replying to your own comment, or to your own reply, is just
// posting twice in a row, and is refused. Once someone else answers, the thread is open to
// you again, so a two-way conversation still works.

const stamp = (row) => {
  const value = Date.parse(row?.created_date || '');
  return Number.isFinite(value) ? value : -Infinity;
};

// Every thread's newest comment, keyed by the id of the comment that started it. Rows may
// arrive in any order; a row with no date never displaces one that has.
export function newestByThread(rows = []) {
  const newest = new Map();
  rows.forEach((row) => {
    const key = row?.parent_id || row?.id;
    if (!key) return;
    const seen = newest.get(key);
    if (!seen || stamp(row) > stamp(seen)) newest.set(key, row);
  });
  return newest;
}

// True when answering this thread would be the viewer answering themselves.
export const isSelfReply = (newestRow, viewerId) =>
  Boolean(viewerId) && newestRow?.author_id === viewerId;
